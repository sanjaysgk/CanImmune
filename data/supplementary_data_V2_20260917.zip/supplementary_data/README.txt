CAN-IMMUNE supplementary data
=============================
Version 2, regenerated 2026-09-03 from CAN-IMMUNE v0.3 (COSMIC v104, DepMap 26Q1).

This supersedes supplymentry_data-20260323T025830Z-3-001.zip, which held the v1 data
built on COSMIC v99 and CCLE 24Q2. The numbers in that archive do not match the revised
manuscript and it should not be used.

Table numbers follow the revised manuscript, where the supplementary items were
renumbered into citation order. The old archive used Table S1 and Table S4 for the same
two folders, and an earlier draft of this archive used Table S9 and Table S12.

Table S8  Mutant peptide library generation for Breast cancer and melanoma
--------------------------------------------------------------------------
The five mutant peptide libraries exported from CAN-IMMUNE and searched in the case
study. Entries are unique 25-mer windows centred on the substituted residue. Variants
are filtered to those seen in at least two samples of the cancer type (CT recurrence
>= 2), except the cell-line-specific library.

  CANIMMUNE_MDA-MB-231_peptides_unique.fasta                 489 entries
  CANIMMUNE_BreastCarcinoma_CL_CTrec2_unique.fasta        12,576 entries
  CANIMMUNE_BreastCarcinoma_CL_and_TS_CTrec2_unique.fasta 25,516 entries
  CANIMMUNE_Melanoma_CL_CTrec2_unique.fasta               22,800 entries
  CANIMMUNE_Melanoma_CL_and_TS_CTrec2_unique.fasta       110,515 entries

These are forward sequences. Decoys and contaminants were added in FragPipe before
searching.

Table S11  Descriptions of supplementary data files
----------------------------------------------------
  TNBC_all_predictions_V2_03092026.csv
      92 identified mutant peptides x each MDA-MB-231 HLA allotype, 891 rows.
      NetMHCpan 4.2 predictions with the library, IFNg state, gene, mutation,
      CAN-IMMUNE accession and spectral evidence for each.

  Melanoma_all_predictions_V2_03092026.csv
      156 identified mutant peptides x each cell line's allotypes, 1,368 rows.

  final_ranked_peptides_list_V2_03092026.csv
      80 ranked candidate peptides with their prioritisation scores.

  structural_models_AlphaFold3_V2_03092026.csv
      21 peptide-HLA complexes, 115 models, with per-model confidence metrics.

  Figure1F_cancertype_tissue_mutation_distribution_V2_03092026.csv
      Source data for Figure 1F: 55 curated cancer types and 31 OncoTree tissue lineages
      with their mutation counts, pulled from the CAN-IMMUNE API.

Verifying
---------
  shasum -a 256 -c SHA256SUMS.txt

Related
-------
  Platform          https://canelib.erc.monash.edu
  Library generator https://github.com/sanjaysgk/MutPep
  Full deposit      doi:10.5281/zenodo.22803271
  Raw MS data       PRIDE PXD023044 and PXD014397
